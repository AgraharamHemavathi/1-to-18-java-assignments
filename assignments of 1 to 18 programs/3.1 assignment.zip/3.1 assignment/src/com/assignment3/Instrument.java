package com.assignment3;

public abstract class Instrument {
	public abstract void play();
}

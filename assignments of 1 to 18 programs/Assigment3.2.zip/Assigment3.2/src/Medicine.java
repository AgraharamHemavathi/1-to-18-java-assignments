
public class Medicine {

}
